# lp > 2024-06-13 4:33pm
https://universe.roboflow.com/tom-j2elk/lp-lnnjr

Provided by a Roboflow user
License: CC BY 4.0

